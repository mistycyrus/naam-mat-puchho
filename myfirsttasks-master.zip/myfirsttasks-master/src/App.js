import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <img
          src='https://images.pexels.com/photos/2777898/pexels-photo-2777898.jpeg'
          width='400'
          height='500'
          alt=''
        />
        <p>
          Hello World
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Hello React
        </a>
      </header>
    </div>
  );
}

export default App;
